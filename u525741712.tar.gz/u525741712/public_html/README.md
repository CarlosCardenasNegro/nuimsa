WEB site de utilidad para la Medicina Nuclear
Este WEB site ha sido diseñado como una herramienta simple de utilidad en las tareas diarias de una unidad de imagen.
Ofrece información para los pacientes e interesados en conocer las características de las diferentes exploraciones realizadas y permite el acceso restringido a los profesionales que trabajan en la unidad donde pueden recoger una historia clínica básica y casos de interés para su posterior discusión.
La utilidad no tiene grandes pretensiones más allá de servir de ayuda en el trabajo diario.
Requerimientos
PHP >= 5.6
Documentación
Este documento describe su utilidad.
Autor
Carlos Cárdenas Negro